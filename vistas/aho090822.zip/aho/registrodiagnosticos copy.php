<?php
if ( !isset( $_SESSION ) ) {
  session_start();
}
$enlaceR="dashboard.php?activo=inicio";
include( 'funciones/funcionesGenerales/conecciones/MariaDB/connsisgm.php' );

$fecha_actual = date( 'd/m/Y' );
$hereg = date( "h:i:A" );

$color="";
if ( isset( $_REQUEST[ "bandera" ] ) ) {
  $bandera=$_REQUEST[ "bandera" ];  //Ver Registro
}
else{
  $bandera=1;  //Crear Registro
}

if ( isset( $_REQUEST[ "pagina_usu" ] ) ) {
  $pagina_usu=$_REQUEST[ "pagina_usu" ];  //Ver 
}
else{
  $pagina_usu="inicio";  //Crear Registro
}

if ( isset( $_REQUEST[ "labor_codigo" ] ) ) {
  $labor_codigo_m=$_REQUEST[ "labor_codigo" ];  //Ver Registro
}
else{
  $labor_codigo_m="";  //Crear Registro
}
if ( isset( $_REQUEST[ "labor" ] ) ) {
  $labor=$_REQUEST[ "labor" ];  //Ver Registro
}
else{
  $labor=0;  //Crear Registro
}

if ( isset( $_REQUEST[ "aspirante_cedula" ] ) ) {
  $aspirante_cedula_m=$_REQUEST[ "aspirante_cedula" ];  
}
else{
  $aspirante_cedula_m="";  
}

if ( isset( $_REQUEST[ "registro_codigo" ] ) ) {
  $registro_codigo_m=$_REQUEST[ "registro_codigo" ];  
}
else{
  $registro_codigo_m="";  
}
$image="public/img/sistema/aspiranteazuloscuro.png";
include( 'funciones/funcionesGenerales/enlaces.php' );

include( 'funciones/funcionesGenerales/cargaFormulario.php' );
include( 'vistas/layouts/stylesstartRegistro.php' );
$colorpie="color:#632a00; font-weight: bold;"
?>

<div class="container-fluid p-4 pt-0" onLoad="limpiarespacios()">
    <div class="mb-2">
      <div class="mt-4" style="font-size: 1.5rem; color:#002c00; font-weight: bold; <?php echo $color; ?>">
      <?php 
          if ( $bandera == 1 ) { ?>
          <img style="position: relative; center: 0px; top: 0px; width: 5%;" src="public/img/sistema/icon/diagnosticoa_verde.png"/>
          &nbsp;
          <?php  echo "Diagnóstico Ambiental";
          } else {?>
            <img style="position: relative; center: 0px; top: 0px; width: 5%;" src=<?php echo $image; ?> />
            &nbsp;
            <?php 
            echo "Diagnóstico Ambiental";
          }                   
        ?>
      </div>
    </div> 
  <ol class="breadcrumb mb-12 ms-12">
    <li class="breadcrumb-item"><a href="dashboard.php?activo=inicio"  style="color: #ee9528">inicio</a></li>
    <li class="breadcrumb-item active" style="color: #da9434"><a href="dashboard.php?activo=ambiente" style="color: #ee9528">Ambiente</a></li>
    <li class="breadcrumb-item active" style="color: #da9434"><a href="dashboard.php?activo=inspeccionesambiente" style="color: #ee9528">Inspecciones</a></li>
    <li class="breadcrumb-item active" style="color: #632a00"><?php echo $titulo; ?></li>
  </ol> 
  <!--<form action="" method="post" name="solicitud" id="form2">  -->
  <form action="" method="post" name="solicitud" id="form2">
    <div class="row">
      <div class="col-xl-12 mt-2"> 
        <div class="card-header" style="border: 1px solid #d4d3df; color: #549127; ">
          <div class="row p-2 pb-0 pt-0">
            <div class="col-xl-9 p-0">
              <b>DIAGNÓSTICO AMBIENTAL</b>
            </div>  
            <div class="col-xl-1">
              <label class="form-label m-0 p-0 mt-2 pt-1">Código</label>
            </div>           
            <div class="col-xl-2 P-0">
              <input type="text" id="aspirante_ced" name="aspirante_ced"  class="form-control" aria-describedby="passwordHelpBlock" required 
              value="<?php 
                if ($bandera==2){
                  echo $aspirante_cedula_m;
                }
              ?>"
              <?php  
                if ($bandera==2){
                  echo "disabled";
                }  ?> >
            </div>
          </div>
        </div>        
        <div class="card mb-2">
          <div class="row mb-1 p-3 pt-1 pb-2" style="color: #632a00">
            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Complejo</label>
              <?php 
                if ($bandera==1){  ?>
                  <select  id="id_estado" name="id_estado" class="chosen-select" onchange="actualiza_municipio()" >
                    <option value='0'>Seleccione Complejo</option>
                    <?php
                    for ( $co = 1; $co <= $cantEstado; $co++ ) {
                      ?>
                    <option  value="<?php echo $co;   ?>">
                    <?php echo $estados[$co][ 'estado' ];   ?>
                    </option>
                    <?php  } ?>
                  </select>
                  <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_estado" name="id_estado" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_estado_m;  ?>"  disabled >
               <?php   }  ?>   
            </div>    
           
            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Area</label>
              <?php 
                if ($bandera==1){  ?>
                  <select  id="id_municipio" name="id_municipio" class="chosen-select" onchange="actualiza_parroquia()">
                    <option value='0'>Seleccione Area</option>
                    <?php
                    for ( $cm = 1; $cm <= $cantM; $cm++ ) {
                      ?>
                    <option  value="<?php echo $cm;  ?>">
                    <?php echo $municipios[$cm][ 'municipio' ] ;   ?>
                    </option>
                    <?php  } ?>
                  </select>
                  <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_municipio" name="id_municipio" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_municipio_m;  ?>" disabled  >
               <?php    
                  }  ?>
            </div>

            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Instalación</label>
              <?php 
                if ($bandera==1){  ?>
                <select  id="id_parroquia" name="id_parroquia" class="chosen-select"  >
                  <option value='0'>Seleccione Instalación</option>
                  <?php
                  for ( $cp = 1; $cp <= $cantP; $cp++ ) {            ?>
                  <option  value="<?php echo $cp;  ?>">
                  <?php echo $parroquias[$cp][ 'parroquia' ];    ?>
                  </option>
                  <?php  } ?>
                </select>
                <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_parroquia" name="id_parroquia" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_parroquia_m;  ?>" disabled   >
               <?php    
                  }  ?>
            </div>               
          </div>
        </div>

        <div class="card mb-2">
          <div class="row mb-1 p-3 pt-1 pb-2" style="color: #632a00">
            <div class="col-xl-6">
              <label for="" class="form-label mt-2">Aspectos a Evaluar</label>
              <input type="text" id="id_estado" name="id_estado" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
              value=""  disabled >
            </div>    
           
            <div class="col-xl-6">
              <label for="" class="form-label mt-2">Condiciones</label>              
              <input type="text" id="aspirante_ced" name="aspirante_ced"  class="form-control" aria-describedby="passwordHelpBlock" required >
            </div>              
          </div>
        </div>

        <!-- INICIO DE DESCRIPCION DE HALLAZGO, RECOMENDACIONES Y RESPONSABLES   -->
        <div class="card mb-0 mt-2" style="color:black; "> 
          <div class="card-header m-0 p-0" style="background: #8eac971a">  
            <div class="row mb-0 p-0 m-0" style=" border: 2px solid #002c00">
              <div class="col-md-12 mt-2" >
                <article style="margin-bottom: 1.8%"> <!-- TABLA UNO DE DESCRIPCION   -->
                  <table class="inventory mt-3 mb-5 pb-1" style="border-collapse: inherit; border:5px double #002c00; " id='tabla_detalle' >
                    <thead>
                      <tr >
                        <th style="text-decoration:none;background: #002c00; width:4%; color: #fff" >#</th>
                        <th style="text-decoration:none;background: #002c00; width:96%; color: #fff; font-size: 150%" >DESCRPCION</th>
                      </tr>
                    </thead>
                    <tbody>                      
                      <tr>
                        <td colspan=1 >
                          <a class="cut" style="text-decoration:none;border: 2px solid #138034de; font-size: 150%;font-weight: bold; background:#002c00; color: white">H1</a>
                          <span style="font-size: 180%; " ></span>
                        </td>
                        <td style="text-decoration:none; width: 96%;">    
                          <span >
                            <div class="card-header" style="background: #8eac971a">    
                              <div class="row mb-1 p-0" > 
                                <div class="col-md-12 col-xs-12 col-lg-12">	
                                  <select class="chosen-select" style="text-decoration:none; text-align: center; width: 100%;">
                                    <option value="">Seleccione Hallazgo H1</option>   
                                    <option  value=""> Hallazgo H1   </option>	
                                  </select> 
                                </div>
                              </div>
                              <!-- TABLA UNO DE RECOMENDACIONES   -->
                              <div class="row " style="margin-bottom: 2%; border: 2.8px dotted #549127; margin-top: 2%;padding:1%; background: #8eac971a"> 
                                <div class="col-md-12 col-xs-12 col-lg-12" id='tabla_detalle2'>	
                                  <div class="row" style="background: #549127;border: 1px double #212d21e0;color: white;font-size: 120%;font-weight: bold;border-radius: 0.2em;" > 
                                    <div class="col-md-1 col-xs-1 col-lg-1" style=" text-decoration: none;font-size: 150%;color: white;">#</div>
                                    <div class="col-md-5 col-xs-5 col-lg-5" style="background: #549127" >	RECOMENDACION</div>
                                    <div class="col-md-6 col-xs-6 col-lg-6" style="background: #77c28d" >RESPONSABLE</div>
                                  </div>
                                  <div class="row " style="background: #fff; border:1px solid rgba(0, 0, 0, 0.125)"> 
                                    <div class="col-md-1 col-xs-1 col-lg-1">	
                                      <a class="cut2" style="position: relative;text-decoration:none;border: 1px solid #138034de; font-size: 100%;font-weight: bold; background:#549127; color: white">C2</a>
                                        <span style="font-size: 180%; " ></span>
                                    </div>
                                    <div class="col-md-5 col-xs-5 col-lg-5" >recomendacion</div>
                                    <div class="col-md-6 col-xs-6 col-lg-6" >descripcion</div>
                                  </div>
                                </div>
                              </div>
                            </div>  
                            <div class="row" style="font-size: 80%; font-weight: bold;" > 
                              <div class="col-md-12 col-xs-12 col-lg-12" style=" text-decoration: none;color: white; text-align: left;">
                                <a class="add" style="text-decoration:none; border: 1px solid #138034de; font-size: 140%;font-weight: bold; background:#549127; color: white; border-radius: 0.5em;">A2</a> 
                              </div>
                            </div>    
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <a class="agregar" style="text-decoration:none; text-decoration:none;border: 2px solid #138034de; font-size: 120%;font-weight: bold; background:#002c00; color: white">H1</a> 
                </article>             
              </div>
            </div>
          </div>
        </div>
        <div class="card mb-0 mt-2">
        <div class="card-header" style="color: #549127; "> <b>&nbsp;ADJUNTAR SOPORTES </b></div>
          <div class="row mb-0 p-0 m-0 pt-0 pb-1">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-0" class="text-center" 
              style=" padding-top:0.5%; padding-bottom: 1%">
              <input type="hidden" name="MAX_FILE_SIZE" value="512000" />
              <input name="archivo1" id="archivo1" type="file" class="form-control" style="font-size:0.8em; margin-top:1%; margin-bottom: 1.5%" />
            </div>                                    
          </div>
        </div>
        <?php if ($bandera==1){  //  ES UN REGISTRO NUEVO   ?>
        <div class="row mt-4 text-center m-0 p-0 mb-2 mb-5">
          <div class="col-xl-2"> </div>         
          <div class="col-xl-4 ">
            <button type="button" class="btn mb-2"  onclick="guardar();" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-fast-forward"></i>&nbsp;&nbsp;Registrar</button>
          </div>
          <div class="col-xl-4"> <a rel="tooltip"  title=" Cancelar " id="Cancelar"  href="dashboard.php?activo=inicio" class="btn" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-undo"></i> Cancelar </a> </div>
          <div class="col-xl-2"> </div>
        </div>
        <?php } ?>
        <?php 
        if ($bandera==2){ 
          include( 'funciones/enlacesRegistro.php' );                  
          //  VISUALIZAR REGISTRO   ?>
          <div class="row mt-4 text-center m-0 p-0 mb-2">
            <div class="col-xl-1"> </div>
            <div class="col-xl-3 ">       </div>
            <div class="col-xl-3 "> 
              <a rel="tooltip"  title=" Cancelar " id="Cancelar" href="<?php echo $enlaceR; ?>"  class="btn" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-undo"></i> Regresar </a> 
            </div>
            <div class="col-xl-2"> </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </form>
</div><br/><br/><br/><br/>
<?PHP include( 'vistas/layouts/jsstartRegistro.php' );  ?>