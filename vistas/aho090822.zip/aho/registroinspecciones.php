<?php
if ( !isset( $_SESSION ) ) {
  session_start();
}
$enlaceR="dashboard.php?activo=inicio";
include( 'funciones/funcionesGenerales/conecciones/MariaDB/connsisgm.php' );

$fecha_actual = date( 'd/m/Y' );
$hereg = date( "h:i:A" );

$color="";
if ( isset( $_REQUEST[ "bandera" ] ) ) {
  $bandera=$_REQUEST[ "bandera" ];  //Ver Registro
}
else{
  $bandera=1;  //Crear Registro
}

if ( isset( $_REQUEST[ "pagina_usu" ] ) ) {
  $pagina_usu=$_REQUEST[ "pagina_usu" ];  //Ver 
}
else{
  $pagina_usu="inicio";  //Crear Registro
}

if ( isset( $_REQUEST[ "labor_codigo" ] ) ) {
  $labor_codigo_m=$_REQUEST[ "labor_codigo" ];  //Ver Registro
}
else{
  $labor_codigo_m="";  //Crear Registro
}
if ( isset( $_REQUEST[ "labor" ] ) ) {
  $labor=$_REQUEST[ "labor" ];  //Ver Registro
}
else{
  $labor=0;  //Crear Registro
}

if ( isset( $_REQUEST[ "aspirante_cedula" ] ) ) {
  $aspirante_cedula_m=$_REQUEST[ "aspirante_cedula" ];  
}
else{
  $aspirante_cedula_m="";  
}

if ( isset( $_REQUEST[ "registro_codigo" ] ) ) {
  $registro_codigo_m=$_REQUEST[ "registro_codigo" ];  
}
else{
  $registro_codigo_m="";  
}
$image="public/img/sistema/aspiranteazuloscuro.png";
include( 'funciones/enlaces.php' );

include( 'funciones/cargaFormulario.php' );
include( 'vistas/layouts/stylesstartRegistro.php' );
$colorpie="color:#549127;"
?>

<div class="container-fluid p-4 pt-0" onLoad="limpiarespacios()">
    <div class="mb-2">
      <div class="mt-4" style="font-size: 1.5rem; color:#002c00; font-weight: bold; <?php echo $color; ?>">
      <?php 
          if ( $bandera == 1 ) { ?>
          <img style="position: relative; center: 0px; top: 0px; width: 5%;" src="public/img/sistema/icon/inspeciona_verde.png"/>
          &nbsp;
          <?php  echo "Inspecciones Ambientales";
          } else {?>
            <img style="position: relative; center: 0px; top: 0px; width: 5%;" src=<?php echo $image; ?> />
            &nbsp;
            <?php 
            echo "Inspecciones Ambientales";
          }                   
        ?>
      </div>
    </div> 
  <ol class="breadcrumb mb-12 ms-12">
    <li class="breadcrumb-item"><a href="dashboard.php?activo=inicio"  style="color: #ee9528">inicio</a></li>
    <li class="breadcrumb-item active" style="color: #da9434"><a href="dashboard.php?activo=ambiente" style="color: #ee9528">Ambiente</a></li>
    <li class="breadcrumb-item active" style="color: #da9434"><a href="dashboard.php?activo=inspeccionesambiente" style="color: #ee9528">Inspecciones</a></li>
    <li class="breadcrumb-item active" style="color: #632a00"><?php echo $titulo; ?></li>
  </ol> 
  <!--<form action="" method="post" name="solicitud" id="form2">  -->
  <form action="" method="post" name="solicitud" id="form2">
    <div class="row">
      <div class="col-xl-12 mt-2"> 
        <div class="card-header" style="border: 1px solid #d4d3df; color: #549127; ">
          <div class="row p-2 pb-0 pt-0">
            <div class="col-xl-9 p-0">
              <b>REPORTE DE INSPECCIÓN AMBIENTAL</b>
            </div>  
            <div class="col-xl-1">
              <label class="form-label m-0 p-0 mt-2 pt-1">Código</label>
            </div>           
            <input type="hidden"id="aspirante_fechReg" name="aspirante_fechReg"  value="<?php echo date( 'Y/m/d' );?>"/>     
            <div class="col-xl-2 P-0">
              <input type="text" id="aspirante_ced" name="aspirante_ced"  class="form-control" aria-describedby="passwordHelpBlock" required 
              value="<?php 
                if ($bandera==2){
                  echo $aspirante_cedula_m;
                }
              ?>"
              <?php  
                if ($bandera==2){
                  echo "disabled";
                }  ?> >
            </div>
          </div>
        </div>        
        <div class="card mb-2">
          <div class="row mb-1 p-3 pt-1 pb-2" style="color: #632a00">
            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Complejo</label>

              <?php 
                if ($bandera==1){  ?>
                  <select  id="id_estado" name="id_estado" class="chosen-select" onchange="actualiza_municipio()" >
                    <option value='0'>Seleccione Complejo</option>
                    <?php
                    for ( $co = 1; $co <= $cantEstado; $co++ ) {
                      ?>
                    <option  value="<?php echo $co;   ?>">
                    <?php echo $estados[$co][ 'estado' ];   ?>
                    </option>
                    <?php  } ?>
                  </select>
                  <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_estado" name="id_estado" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_estado_m;  ?>"  disabled >
               <?php   }  ?>   
            </div>    
           
            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Area</label>
              <?php 
                if ($bandera==1){  ?>
                  <select  id="id_municipio" name="id_municipio" class="chosen-select" onchange="actualiza_parroquia()">
                    <option value='0'>Seleccione Area</option>
                    <?php
                    for ( $cm = 1; $cm <= $cantM; $cm++ ) {
                      ?>
                    <option  value="<?php echo $cm;  ?>">
                    <?php echo $municipios[$cm][ 'municipio' ] ;   ?>
                    </option>
                    <?php  } ?>
                  </select>
                  <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_municipio" name="id_municipio" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_municipio_m;  ?>" disabled  >
               <?php    
                  }  ?>
            </div>

            <div class="col-xl-4">
              <label for="" class="form-label mt-2">Instalación</label>
              <?php 
                if ($bandera==1){  ?>
                <select  id="id_parroquia" name="id_parroquia" class="chosen-select"  >
                  <option value='0'>Seleccione Instalación</option>
                  <?php
                  for ( $cp = 1; $cp <= $cantP; $cp++ ) {            ?>
                  <option  value="<?php echo $cp;  ?>">
                  <?php echo $parroquias[$cp][ 'parroquia' ];    ?>
                  </option>
                  <?php  } ?>
                </select>
                <?php
                }                  
                if ($bandera==2){  ?>
                  <input type="text" id="id_parroquia" name="id_parroquia" class="form-control" aria-describedby="passwordHelpBlock" placeholder="" "" 
                  value="<?php echo $aspirante_parroquia_m;  ?>" disabled   >
               <?php    
                  }  ?>
            </div>               
          </div>
        </div>
        <div class="card mb-0 mt-2">
          <div class="card-header" style="color:#549127;"> 
              &nbsp;<b>DESCRIPCIÓN DE HALLAZGOS </b>
          </div>
          <div class="row mb-0 p-0 m-0">
            <div class="col-xl-12 mt-2">
              <?php if ($bandera==1){  // Creando Registro      ?>
              <article style="margin-bottom: 1.8%">
                <table class="inventory" style="border-collapse: inherit;" id='tabla_detalle' >
                  <thead>
                    <tr >
                      <th colspan=1  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">#</th>
                      <th colspan=5  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">HALLAZGO </th>
                      <th colspan=4  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">RESPONSABLE</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td colspan=1 style="text-decoration:none"><a class="cut" style="text-decoration:none">-</a><span ></span></td>
                      <td colspan=5 ><span ><input name="experiencia_ente_o_empresa[]" id="experiencia_ente_o_empresa" style="text-transform:uppercase;" /></span></td>
                      <td colspan=4 ><span ><input name="experiencia_tiempo[]" id="experiencia_tiempo[]" /><a class="add" style="text-decoration:none">+</a> </td>                
                          

                      <td hidden="hidden"><input type="hidden" name="carticulo[]" id="carticulo[]" value="" /></td>
                    </tr>
                  </tbody>
                </table>
                <a class="add" style="text-decoration:none">+</a> </article>
              <?php } 
               if ($bandera==2){  // mostrar datos     ?>
                <article style="margin-bottom: 1.8%">
                  <table class="inventory" style="border-collapse: inherit;" id='tabla_detalle' >
                    <thead>
                      <tr >
                        <th colspan=1  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">#</th>
                        <th colspan=4  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">ACTIVIDAD</th>
                        <th colspan=2  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">FECHA INICIO</th>
                        <th colspan=2  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">RESPONSABLE</th>
                        <th colspan=2  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">FECHA CIERRE PLANIF</th>
                        <th colspan=5  style="background: #e2e6f0;color: #632a00;border: 1px solid #bfb6b6;">FEHCA CIERRE</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php echo $imprime_linea = imprime_fila(2,$registro_codigo_m);?>            
                    </tbody> 
                  </table>
                  </article>
                <?php } ?>
            </div>
          </div>
        </div>

        <?php if ($bandera==1){        ?>     

        <div class="card mb-0 mt-2">
        <div class="card-header" style="color: #549127; "> <b>&nbsp;ADJUNTAR SOPORTES </b></div>
          <div class="row mb-0 p-0 m-0 pt-0 pb-1">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-0" class="text-center" 
              style=" padding-top:0.5%; padding-bottom: 1%">
              <input type="hidden" name="MAX_FILE_SIZE" value="512000" />
              <input name="archivo1" id="archivo1" type="file" class="form-control" style="font-size:0.8em; margin-top:1%; margin-bottom: 1.5%" />
            </div>                                    
          </div>
        </div>
        <?php } ?>
        <?php if ($bandera==1){  //  ES UN REGISTRO NUEVO   ?>
        <div class="row mt-4 text-center m-0 p-0 mb-2">
          <div class="col-xl-2"> </div>         
          <div class="col-xl-4 ">
            <button type="button" class="btn mb-2"  onclick="guardar();" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-fast-forward"></i>&nbsp;&nbsp;Registrar</button>
          </div>
          <div class="col-xl-4"> <a rel="tooltip"  title=" Cancelar " id="Cancelar"  href="dashboard.php?activo=inicio" class="btn" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-undo"></i> Cancelar </a> </div>
          <div class="col-xl-2"> </div>
        </div>
        <?php } ?>
        <?php 
        if ($bandera==2){ 
          include( 'funciones/enlacesRegistro.php' );                  
          //  VISUALIZAR REGISTRO   ?>
          <div class="row mt-4 text-center m-0 p-0 mb-2">
            <div class="col-xl-1"> </div>
            <div class="col-xl-3 ">       </div>
            <div class="col-xl-3 "> 
              <a rel="tooltip"  title=" Cancelar " id="Cancelar" href="<?php echo $enlaceR; ?>"  class="btn" style="min-width: 100%; width: 100%;  max-width: 100%; background-color: #632a00; color: white"> <i class="fa fa-undo"></i> Regresar </a> 
            </div>
            <div class="col-xl-2"> </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </form><br/><br/><br/><br/>
</div>
<?PHP include( 'vistas/layouts/jsstartRegistro.php' );  ?>